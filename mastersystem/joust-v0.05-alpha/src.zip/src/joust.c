#include <stdlib.h>
#include <string.h>
#include <sms.h>

#define NUMBER_0_TILE 0x01
#define SCORE_X 26
#define SCORE_Y 1
#define MAX_VISIBLE_SPRITES 10
#define VISIBLE_BKG_WIDTH 32
#define FULL_BKG_WIDTH 32
#define VISIBLE_BKG_PIXEL_WIDTH (VISIBLE_BKG_WIDTH << 3)
#define VISIBLE_BKG_HEIGHT 24
#define VISIBLE_BKG_PIXEL_HEIGHT (VISIBLE_BKG_HEIGHT << 3)
#define FULL_BKG_HEIGHT 28
#define FULL_PLAYFIELD_HEIGHT 40
#define GRAVITY 0x20
#define BOOST 0x200
#define PLAYER1_TILE 0x00
#define ENEMY_TILE 0x40
#define MIRROR_TILE_OFS 0x10

typedef struct _actor {
	int x, y;
	char w, h;
	fixed step_x, step_y;
	fixed spd_x, spd_y;
	int top, left, width, height;
	unsigned int tile_no;
	char on_ground;
	char horiz_collision;
	char facing_left;
	int  target_y;
	char wingbeat_delay;
	char mode;
} actor;

typedef struct _envyronment {
	unsigned char bkg_pal[16];
	unsigned int score, prev_score;
	unsigned int timer;
} envyronment;

//extern unsigned char terrain_tileset_apk[];
extern unsigned char terrain_tileset[];
//extern unsigned char sprite_tileset_apk[];
extern unsigned char sprite2_til[];
extern unsigned char pal_terrain[];
extern unsigned char pal_sprite[];
extern unsigned int level1_bkg[];

void load_main_tileset() {
//	unsigned char buffer[4096];
//	aplib_depack(terrain_tileset_apk, buffer);
//	load_tiles(buffer, 0, 256, 4);
//	aplib_depack(sprite_tileset_apk, buffer);
//	load_tiles(buffer, 64, 64, 4);
	load_tiles(terrain_tileset, 0, 256, 4);
	load_tiles(sprite2_til, 256, 192, 4);
}

int asr(int n, int cnt) {
	if (n < 0) {
		return -((-n) >> cnt);
	} else {
		return n >> cnt;
	}
}

void memsetw(unsigned int *p, unsigned int value, int count) {
	for (; count; count--, p++) {
		*p = value;
	}
}

int max(int a, int b) {
	return (a > b ? a : b);
}

int min(int a, int b) {
	return (a < b ? a : b);
}

char collide_rect(int x1, int y1, int w1, int h1, int x2, int y2, int w2, int h2) {

    int left1, left2;
    int right1, right2;
    int top1, top2;
    int bottom1, bottom2;

    left1 = x1;
    left2 = x2;
    right1 = x1 + w1;
    right2 = x2 + w2;
    top1 = y1;
    top2 = y2;
    bottom1 = y1 + h1;
    bottom2 = y2 + h2;

    if (bottom1 < top2) return(0);
    if (top1 > bottom2) return(0);

    if (right1 < left2) return(0);
    if (left1 > right2) return(0);

    return(1);

}

/**
 * x and y are given in map coordinates
 **/
char get_map_tile(unsigned int *map, int mx, int my) {
	return *(map + (my << 5) + (mx & 0x1F));
}

/**
 * x, y, w and h are given in screen pixel coordinates
 **/
char collide_rect_map(unsigned int *map, int x, int y, int w, int h) {
	int left = x >> 3;
	int right = ((x+w+7) >> 3);
	int top = y >> 3;
	int bottom = ((y+h+7) >> 3);
	int i, j;

	for (i = left; i != right; i++) {
		for (j = top; j != bottom; j++) {
			if (get_map_tile(map, i, j) != 0x24) {
				return 1;
			}
		}
	}
	return 0;
}

char collide_actor_map(unsigned int *map, actor *act) {
	return collide_rect_map(map, act->x + act->left, act->y + act->top, act->width, act->height);
}

char shakeoff_actor_horiz(actor *act) {
	int x = act->x;
	int y = act->y;
	UWORD spd_x_cnt = abs(act->spd_x.w);

	if (act->spd_x.w == 0) {
		return;
	}

	while (spd_x_cnt > 0) {
		if ((WORD)act->spd_x.w < 0) {
			x++;
		} else {
			x--;
		}

		if (!collide_rect_map(level1_bkg, x + act->left, y + act->top, act->width, act->height)) {
			act->x = x;
			act->spd_x.w = -act->spd_x.w;
			return 1;
		}

		spd_x_cnt -= 0x100;
	}

	return 0;
}

char shakeoff_actor_vert(actor *act) {
	int x = act->x;
	int y = act->y;
	int spd_y_cnt = abs(act->spd_y.w);

	if (act->spd_y.w == 0) {
		return;
	}

	while (spd_y_cnt > 0) {
		if ((WORD)act->spd_y.w < 0) {
			y++;
		} else {
			y--;
		}

		if (!collide_rect_map(level1_bkg, x + act->left, y + act->top, act->width, act->height)) {
			act->y = y;
			if ((WORD)act->spd_y.w < 0) {
				act->spd_y.w = -act->spd_y.w;
			} else {
				if (act->spd_y.w > GRAVITY) {
					act->spd_y.w = asr(-act->spd_y.w, 1);
				} else {
					act->spd_y.w = 0;
				}
			}
			return 1;
		}

		spd_y_cnt -= 0x100;
	}

	return 0;
}

void move_actor(actor *act) {
	unsigned int tx, ty;
	unsigned int tilenum;

	act->step_y.w += act->spd_y.w;
	act->y += (BYTE)act->step_y.b.h;
	act->step_y.b.h = 0;

	act->on_ground = 0;
	if (collide_actor_map(level1_bkg, act)) {
		act->on_ground = ((WORD)act->spd_y.w > 0);
		shakeoff_actor_vert(act);
	}

	(WORD)act->step_x.w += (WORD)act->spd_x.w;
	act->x += (BYTE)act->step_x.b.h;
	act->step_x.w = 0;

	act->horiz_collision = 0;
	if (collide_actor_map(level1_bkg, act)) {
		act->horiz_collision = 1;
		shakeoff_actor_horiz(act);
	}

	if (act->x + act->left < -(act.width >> 1)) {
		act->x += VISIBLE_BKG_PIXEL_WIDTH;
	} else if (act->x + act->left > VISIBLE_BKG_PIXEL_WIDTH - (act.width >> 1)) {
		act->x -= VISIBLE_BKG_PIXEL_WIDTH;
	}
}

void draw_actor(actor *act, int *curr_spr) {
	int x, y, tile;
	int i, j, y2;

	if (*curr_spr > 63) {
		return;
	}

	x = act->x;
	y = act->y;
	tile = act->tile_no;

	if ((x < -16) || (x > 255) ||
	    (y < -16) || (y > 192)) {
		return;
	}

	for (i = act->w; i; i--, x += 8) {
		for (j = act->h, y2 = y; j; j--, y2 += 16, tile += 2, (*curr_spr)++) {
			set_sprite(*curr_spr, x, y2, tile);
		}
	}
}

void buzzard_ai(actor *enemy, actor *player) {
	if (enemy->mode) {
		if (enemy->x > player->x) {
			enemy->facing_left = 1;
		} else if (enemy->x < player->x) {
			enemy->facing_left = 0;
		}

		enemy->target_y = player->y + 8;

		if (!(rand() & 0x0F)) { // If you want more agressivity, increase this mask
			enemy->mode = 0;
		}
	} else {
		if (enemy->horiz_collision) {
			enemy->facing_left = !enemy->facing_left;
		}

		if (!(rand() & 0x1F)) {
			enemy->target_y = rand() % VISIBLE_BKG_PIXEL_HEIGHT;
		}

		if (!(rand() & 0xFF)) { // If you want more agressivity, decrease this mask
			enemy->mode = 1;
		}
	}

	if (enemy->facing_left) {
		if ((BYTE)enemy->spd_x.b.h > -0x03) {
			enemy->spd_x.w -= 0x50;
		}
	} else {
		if ((BYTE)enemy->spd_x.b.h < 0x03) {
			enemy->spd_x.w += 0x50;
		}
	}

	enemy->tile_no = ENEMY_TILE;
	if (!enemy->wingbeat_delay) {
		if (enemy->y > enemy->target_y) {
			enemy->tile_no += 4;
			enemy->spd_y.w = -BOOST;
			enemy->wingbeat_delay = 3;
		}
	} else {
		if (enemy->wingbeat_delay > 2) {
			enemy->tile_no += 4;
		}
		enemy->wingbeat_delay--;
	}
	if (enemy->facing_left) {
		enemy->tile_no += MIRROR_TILE_OFS;
	}

	enemy->spd_y.w += GRAVITY;
}

void draw_number(int x, int y, unsigned int n, int width) {
	unsigned int buffer[5];
	unsigned int *p = buffer + width - 1;

	memsetw(buffer, 0x0000, 5);
	do {
		*p = NUMBER_0_TILE + (n % 10);
		p--;
		n /= 10;
	} while (n != 0);

	set_bkg_map(buffer, x, y, width, 1);
}

void refresh_score(envyronment *envyro) {
	if (envyro->score != envyro->prev_score) {
		draw_number(SCORE_X, SCORE_Y, envyro->score, 5);
		envyro->prev_score = envyro->score;
	}
}

void draw_bkg() {
	set_bkg_map(level1_bkg, 0, 0, 32, 24);
}

void main() {
	int i;
	actor player;
	actor enemy[4], *enm;
	int joy;
	int curr_spr;
	unsigned char ch;
	envyronment envyro;

	load_palette(pal_terrain, 0, 16);
	load_palette(pal_sprite, 16, 16);
	load_main_tileset();
	for (i = 0; i != 64; i++) {
		set_sprite(i, -16, -16, 0);
	}
	set_vdp_reg(VDP_REG_FLAGS0, VDP_REG_FLAGS0_CHANGE | VDP_REG_FLAGS0_LHS);
	set_vdp_reg(VDP_REG_FLAGS1, VDP_REG_FLAGS1_SCREEN | VDP_REG_FLAGS1_8x16);
	set_vdp_reg(0x86, 0x04); // Use the second tileset for the sprites

	memcpy(envyro.bkg_pal, pal_terrain, 16);

	envyro.score = 0;
	envyro.prev_score = 1;
	refresh_score(&envyro);

	player.x = 160;
	player.y = 100;
	player.tile_no = PLAYER1_TILE;
	player.w = 2;
	player.h = 1;
	player.top = 2;
	player.left = 4;
	player.width = 8;
	player.height = 14;
	player.facing_left = 0;

	for (i = 0; i != 4; i++) {
		enemy[i].x = i << 5;
		enemy[i].y = 8;
		enemy[i].tile_no = ENEMY_TILE;
		enemy[i].w = 2;
		enemy[i].h = 1;
		enemy[i].top = 2;
		enemy[i].left = 4;
		enemy[i].width = 8;
		enemy[i].height = 14;
		enemy[i].target_y = 16 * i;
	}

	draw_bkg();

	for (;;) {
		joy = read_joypad1();

		if (joy & JOY_LEFT) {
			player->facing_left = 1;
			if ((BYTE)player.spd_x.b.h > -0x03) {
				player.spd_x.w -= 0x50;
			}
		} else if (joy & JOY_RIGHT) {
			player->facing_left = 0;
			if ((BYTE)player.spd_x.b.h < 0x03) {
				player.spd_x.w += 0x50;
			}
		}

		player.tile_no = PLAYER1_TILE;
		if (joy & JOY_FIREA) {
			player.tile_no = PLAYER1_TILE + 4;
			if (!player.wingbeat_delay) {
				player.spd_y.w = -0x200;
				player.wingbeat_delay = 1;
			}
		} else {
			player.wingbeat_delay = 0;
		}
		if (player.facing_left) {
			player.tile_no += MIRROR_TILE_OFS;
		}

		player.spd_y.w += GRAVITY;
		move_actor(&player);

		for (i = 0, enm = enemy; i != 4; i++, enm++) {
			buzzard_ai(enm, &player);
			move_actor(enm);
		}

		wait_vblank_noint();

		curr_spr = 0;
		draw_actor(&player, &curr_spr);
		for (i = 0, enm = enemy; i != 4; i++, enm++) {
			draw_actor(enm, &curr_spr);
		}

		if (curr_spr < MAX_VISIBLE_SPRITES) {
			for (; curr_spr != MAX_VISIBLE_SPRITES; curr_spr++) {
				set_sprite(curr_spr, -16, -16, 0);
			}
		}

		envyro.timer++;
	}
}

#asm
;._terrain_tileset_apk
;	BINARY	"terrain.apk"
._terrain_tileset
	BINARY	"terrain.til"
;._sprite_tileset_apk
;	BINARY	"sprite2.apk"
._sprite2_til
	BINARY	"sprite2.til"
._pal_terrain
	BINARY	"terrain2.pal"
._pal_sprite
	BINARY	"sprite.pal"
._level1_bkg
	BINARY	"level1.bkg"
#endasm
