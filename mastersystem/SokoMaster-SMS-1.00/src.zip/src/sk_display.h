#ifndef _SK_DISPLAY_
#define _SK_DISPLAY_

extern void sk_render_map(sk_levelmap *level);
extern void sk_render_thumbnail(sk_levelmap *level, UBYTE x, UBYTE y, UBYTE num, UBYTE enabled);

#endif /*_SK_DISPLAY_*/
