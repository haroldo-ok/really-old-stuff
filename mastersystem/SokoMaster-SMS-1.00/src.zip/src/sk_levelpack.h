#ifndef _SK_LEVELPACK_
#define _SK_LEVELPACK_

extern UBYTE *lpk_seek_map(UBYTE *mappack, UBYTE mapnum);
extern void lpk_load_map(sk_levelmap *level, UBYTE *mappack, UBYTE mapnum);
extern UWORD lpk_count_maps(UBYTE *mappack);

#endif /*_SK_LEVELPACK_*/
