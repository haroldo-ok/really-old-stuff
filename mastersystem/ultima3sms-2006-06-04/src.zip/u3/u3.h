//#define LIKSANG 1

typedef struct battlemonsters
{
	UBYTE x ;
	UBYTE y ;
	UBYTE hp ;

} BATTLEMONSTERS ;

//typedef struct battleplayers {
//   UBYTE x ;
//   UBYTE y ;
//   UBYTE tile ;
//} BATTLEPLAYERS ;

typedef struct player
{
	unsigned char name[7] ;	 //line 1
	UWORD currHP ; //line 2
	UWORD maxHP ;
	UBYTE status ;	//line 2  good, poisoned, dead, ashes
	UWORD food ;  //line 3
	UWORD gold ;
	UBYTE magic ; //line 4
	UBYTE level ; //ilne 4
	UWORD exp ;	//line5
	UBYTE str ;
	UBYTE dex ;
	UBYTE intel ;
	UBYTE wis ;
	UBYTE gems ;
	UBYTE keys ;
	UBYTE powders ;
	UBYTE torches ;
	UBYTE weapon ;
	UBYTE armor ;
	UBYTE weapons[16] ;
	UBYTE armors[8] ;
	UBYTE sex ;
	UBYTE race ;
	UBYTE skill ; //line2
	UBYTE markcard ; //4 marks, 4 cards
	UBYTE inparty ;
	UBYTE tile ;
	UBYTE x ;
	UBYTE y ;
	UBYTE rosterpos ;
	unsigned char reserved[64] ;
} PLAYER ;

typedef struct monster
{
	UBYTE tile;
	UBYTE x,y ;
	UBYTE attribs ;	 //high nibble : 1=attack char if near, 0=ignore
					 //low nibble  : 0=sessile 2=move randomly, 1=move towards character
	UBYTE whichtalk ;
	// high nibble = which special other,yell
	//EVOCARE
	//INSERT=1
	//BRIBE=2
	//DIG=3
	//PRAY=4
	//SEARCH=5
	//SCORE

} MONSTER ;

#define MONSTERSIZE 5L

#define TILESET_SIZE 64

#define MAP_W 64
#define MAP_W_MASK 0x3F
#define MAP_H 64
#define MAP_H_MASK 0x3F

#define VIEWPORT_W 9
#define VIEWPORT_H 10

//0 - walk on by foot
//1 - walk on by ship
//2 - enterable
//3 - attackable/transactable
//4 - opaque
//5 - boardable
#define CARDDEATH 0x01
#define CARDLOVE  0x02
#define CARDSOL   0x04
#define CARDMOON  0x08
#define MARKFORCE 0x10
#define MARKFIRE  0x20
#define MARKSNAKE 0x40
#define MARKKING  0x80

#define U3SHAPE_WATER       0  // Full animation
#define U3SHAPE_GRASS       1
#define U3SHAPE_BRUSH       2
#define U3SHAPE_TREES       3
#define U3SHAPE_MOUNTAINS   4
#define U3SHAPE_DUNGEON     5
#define U3SHAPE_TOWN        6
#define U3SHAPE_CASTLE      7
#define U3SHAPE_BRICK       8
#define U3SHAPE_CHEST       9  // Lower two bits if chest: 0x00 Brick 0x01 Grass 0x02 Brush 0x03 Trees
#define U3SHAPE_HORSE       10
#define U3SHAPE_SHIP        11
#define U3SHAPE_WHIRL       12 // Has two animations, but is an exception
#define U3SHAPE_SEAMONSTER  13 // First monster
#define U3SHAPE_OCTOPUS     14
#define U3SHAPE_PIRATESHIP  15
#define U3SHAPE_MERCHANT    16 // First with two animations
#define U3SHAPE_JESTER      17
#define U3SHAPE_GUARD       18
#define U3SHAPE_KING        19
#define U3SHAPE_FIGHTER     20
#define U3SHAPE_CLERIC      21
#define U3SHAPE_WIZARD      22
#define U3SHAPE_THIEF       23
#define U3SHAPE_ORC         24
#define U3SHAPE_SKELETON    25
#define U3SHAPE_OGRE        26
#define U3SHAPE_DAEMON      27
#define U3SHAPE_PINCHER     28
#define U3SHAPE_DRAGON      29
#define U3SHAPE_BALRON      30 // Last monster, Last with two animations
#define U3SHAPE_EXODUS      31
#define U3SHAPE_FORCE       32 // Full animation
#define U3SHAPE_FIRE        33 // Full animation
#define U3SHAPE_MOONGATE    34 // Full animation
#define U3SHAPE_WALL        35
#define U3SHAPE_BLANK       36
#define U3SHAPE__           37
#define U3SHAPE_A           38 // Letters that are missing: "JKQvXZ"
#define U3SHAPE_B           39
#define U3SHAPE_C           40
#define U3SHAPE_D           41
#define U3SHAPE_E           42
#define U3SHAPE_F           43
#define U3SHAPE_G           44
#define U3SHAPE_H           45
#define U3SHAPE_I           46
#define U3SHAPE_U           47 // U doubles as V when the need arises
#define U3SHAPE_Y           48
#define U3SHAPE_L           49
#define U3SHAPE_M           50
#define U3SHAPE_N           51
#define U3SHAPE_O           52
#define U3SHAPE_P           53
#define U3SHAPE_W           54
#define U3SHAPE_R           55
#define U3SHAPE_S           56
#define U3SHAPE_T           57
#define U3SHAPE_SERPENTTAIL 58
#define U3SHAPE_SERPENTHEAD 59
#define U3SHAPE_BLUEBALL    60 // Normal damage
#define U3SHAPE_PINKBALL    61 // Magical damage
#define U3SHAPE_SHRINE      62
#define U3SHAPE_AVATAR      63
#define U3SHAPE_ANIMATIONOFFSET 48 // What to add to a shape for its second animation
#define U3SHAPE_ANIMATIONFIRST  16 // First shape that has two animations
#define U3SHAPE_ANIMATIONLAST   30 // Last shape that has two animations
#define U3SHAPE_WHIRL2          79 // The second anitmation for the whirlpool
#define U3SHAPE_TOWN2           80 // The second animation for the town
#define U3SHAPE_CASTLE2         81 // The second animation for the castle
#define U3SHAPE_EXODUS2         82 // The second animation for exodus
#define U3SHAPE_SHIP2           83 // The second animation for the ship
#define U3SHAPE_LAST        63     // The last shape that can be drawn (raw shape# without anitmation)
