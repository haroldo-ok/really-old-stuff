#include <sms.h>
#include <string.h>
#include "u3.h"

typedef struct envyronment {
	int map_x, map_y;
	int ply_x, ply_y;
	char timer;
	int next_sprite;
	unsigned char used_tiles[TILESET_SIZE];
	unsigned char *map;
};

typedef struct tile_def {
	int tile_number;
	char frame_mask;
};

typedef struct sprite_rec {
	unsigned char x, y;
	unsigned char tile;
	unsigned char flag;
};

unsigned char bkg_pal1[] = {0x00, 0x10, 0x20, 0x30, 0x04, 0x08, 0x0C, 0x01,
				0x02, 0x03, 0x07, 0x0F, 0x3A, 0x15, 0x2A, 0x3F};

unsigned char spr_pal1[] = {0x00, 0x04, 0x08, 0x05, 0x30, 0x24, 0x01, 0x02,
				0x11, 0x19, 0x0B, 0x03, 0x1B, 0x15, 0x2A, 0x3F};

struct tile_def tileset_map[] = {
	{0, 0x03},      // U3SHAPE_WATER
	{4, 0},			// U3SHAPE_GRASS
	{5, 0},			// U3SHAPE_BRUSH
	{6, 0},			// U3SHAPE_TREES
	{7, 0},			// U3SHAPE_MOUNTAINS
	{8, 0},			// U3SHAPE_DUNGEON
	{9, 0x01},		// U3SHAPE_TOWN
	{11, 0x01},		// U3SHAPE_CASTLE
	{13, 0},		// U3SHAPE_BRICK
	{52, 0},		// U3SHAPE_CHEST
	{53, 0},		// U3SHAPE_HORSE
	{54, 0x01},		// U3SHAPE_SHIP
	{56, 0x01},		// U3SHAPE_WHIRL
	{60, 0x01},		// U3SHAPE_SEAMONSTER
	{62, 0x01},		// U3SHAPE_OCTOPUS
	{64, 0x01},		// U3SHAPE_PIRATESHIP
	{66, 0x01},		// U3SHAPE_MERCHANT
	{68, 0x01},		// U3SHAPE_JESTER
	{72, 0x03},		// U3SHAPE_GUARD
	{76, 0x01},		// U3SHAPE_KING
	{80, 0x01},		// U3SHAPE_FIGHTER
	{84, 0x01},		// U3SHAPE_CLERIC
	{88, 0x01},		// U3SHAPE_WIZARD
	{92, 0x01},		// U3SHAPE_THIEF
	{96, 0x03},		// U3SHAPE_ORC
	{100, 0x03},	// U3SHAPE_SKELETON
	{104, 0x03},	// U3SHAPE_OGRE
	{108, 0x03},	// U3SHAPE_DAEMON
	{112, 0x03},	// U3SHAPE_PINCHER
	{116, 0x03},	// U3SHAPE_DRAGON
	{120, 0x03},	// U3SHAPE_BALRON
	{14, 0x03},		// U3SHAPE_EXODUS
	{18, 0},		// U3SHAPE_FORCE
	{19, 0},		// U3SHAPE_FIRE
	{20, 0x03},		// U3SHAPE_MOONGATE
	{51, 0},		// U3SHAPE_WALL
	{24, 0},		// U3SHAPE_BLANK
	{25, 0},		// U3SHAPE__
	{26, 0},		// U3SHAPE_A
	{27, 0},		// U3SHAPE_B
	{28, 0},		// U3SHAPE_C
	{29, 0},		// U3SHAPE_D
	{30, 0},		// U3SHAPE_E
	{31, 0},		// U3SHAPE_F
	{32, 0},		// U3SHAPE_G
	{33, 0},		// U3SHAPE_H
	{34, 0},		// U3SHAPE_I
	{35, 0},		// U3SHAPE_U
	{36, 0},		// U3SHAPE_Y
	{37, 0},		// U3SHAPE_L
	{38, 0},		// U3SHAPE_M
	{39, 0},		// U3SHAPE_N
	{40, 0},		// U3SHAPE_O
	{41, 0},		// U3SHAPE_P
	{42, 0},		// U3SHAPE_W
	{43, 0},		// U3SHAPE_R
	{44, 0},		// U3SHAPE_S
	{45, 0},		// U3SHAPE_T
	{78, 0},		// U3SHAPE_SERPENTTAIL
	{79, 0},		// U3SHAPE_SERPENTHEAD
	{132, 0x03},	// U3SHAPE_BLUEBALL
	{134, 0x03},	// U3SHAPE_PINKBALL
	{48, 0},		// U3SHAPE_SHRINE
	{124, 0x01}		// U3SHAPE_AVATAR
};

extern unsigned char frame_map[];
extern unsigned char frame_tiles[];
extern unsigned char u3_font[];

extern unsigned char u3_tileset[];
extern unsigned char british_map[];
extern unsigned char sosaria_map[];

extern unsigned char timer;

int get_tile_number(struct envyronment *envyro, int n) {
/*	struct tile_def *tile;
	tile = tileset_map + (n >> 2);
	n = (tile->tile_number + ((envyro->timer >> 1) & tile->frame_mask)) << 2;*/

	return n;
}

void draw_tile(struct envyronment *envyro, int x, int y, int n) {
	unsigned int meta_tile[4];
	unsigned int *p = meta_tile;
	int n2;

	x <<= 1;
	x++;
	y <<= 1;
	y++;
//	n &= 0xFC;

//	n = get_tile_number(envyro, n);
	n2 = n << 2;

	envyro->used_tiles[n] = TRUE;

	*p = n2; p++; n2 += 2;
	*p = n2; p++; n2--;
	*p = n2; p++; n2 += 2;
	*p = n2;

	set_bkg_map(meta_tile, x, y, 2, 2);

/*	if ((tileset_map[n].tile_number > 47) && (tileset_map[n].tile_number != 51)) {
		p = meta_tile;
		*p = 0x180; p++;
		*p = 0x180; p++;
		*p = 0x180; p++;
		*p = 0x180;
		set_bkg_map(meta_tile, x, y, 2, 2);

		if (envyro->next_sprite < 64) {
			x <<= 3;
			y <<= 3;
			n2 = n << 2;
			set_sprite(envyro->next_sprite, x, y, n);
			envyro->next_sprite++;
			n += 2;
			x += 8;
			set_sprite(envyro->next_sprite, x, y, n);
			envyro->next_sprite++;
		}
	} */
}

void draw_sprite_tile(struct envyronment *envyro, int x, int y, int n) {
	unsigned int meta_tile[4];
	unsigned int *p = meta_tile;

	x -= envyro->map_x;
	x &= MAP_W_MASK;
	y -= envyro->map_y;
	y &= MAP_H_MASK;

	if ((envyro->next_sprite < 64) && (x >= 0) && (x < VIEWPORT_W) && (y >= 0) && (y < VIEWPORT_H)) {
		envyro->used_tiles[n] = TRUE;

		x <<= 4;
		x += 8;
		y <<= 4;
		y += 7;
		n = n << 2;
		set_sprite(envyro->next_sprite, x, y, n);
		envyro->next_sprite++;
		n += 2;
		x += 8;
		set_sprite(envyro->next_sprite, x, y, n);
		envyro->next_sprite++;
	}
}

void draw_map_line(struct envyronment *envyro, int x, int y, unsigned char *p) {
	int i;

	for (i = 0; i != VIEWPORT_W; i++, x++, p++) {
		if (x == MAP_W) {
			p -= MAP_W;
			x &= MAP_W_MASK;
		}
		draw_tile(envyro, i, y, *p);
	}
}

void draw_map(struct envyronment *envyro, int x, int y) {
	int i;
	unsigned char *p = envyro->map + x + (y << 6);
	struct sprite_rec *spr = envyro->map + (64*64);

	envyro->map_x = x;
	envyro->map_y = y;
	envyro->ply_x = x + (VIEWPORT_W >> 1); // Just for testing
	envyro->ply_y = y + (VIEWPORT_H >> 1); // Just for testing

	memset(envyro->used_tiles, FALSE, TILESET_SIZE);

	for (i = 0; i != VIEWPORT_H; i++, y++, p += MAP_W) {
		if (y == MAP_H) {
			p -= (MAP_W*MAP_H);
			y &= MAP_H_MASK;
		}
		draw_map_line(envyro, x, i, p);
	}


	envyro->next_sprite = 0;
	draw_sprite_tile(envyro, envyro->ply_x, envyro->ply_y, U3SHAPE_AVATAR);
	for (i = 64; i; i--, spr++) {
		if (spr->tile) {
			draw_sprite_tile(envyro, spr->x, spr->y, spr->tile);
		}
	}

	while (envyro->next_sprite < 64) {
		set_sprite(envyro->next_sprite, 0, 200, 0);
		envyro->next_sprite++;
	}
}

void animate_tileset(struct envyronment *envyro) {
	int i;
	int n;
	struct tile_def *tile = tileset_map;
	unsigned char *used = envyro->used_tiles;

	for (i = 0; i != (TILESET_SIZE*4); i += 4, tile++, used++) {
		if (tile->frame_mask && *used) {
			n = (tile->tile_number + ((envyro->timer >> 1) & tile->frame_mask));
			load_tiles(u3_tileset+(n << 7), i, 4, 4);
		}
	}
}

char default_transact_text[] = "\nGood day!\n\n";
char default_enemy_transact_text[] = "Eat Death Scum!\n";

void display_text(struct envyronment *envyro) {
	int i;
	unsigned char *p = envyro->map + ((64*64) + (64*4));
	unsigned int *offs = p;
	struct sprite_rec *spr = envyro->map + (64*64);
	struct sprite_rec *selspr = NULL;
	unsigned int buf[12*14];
	unsigned int *bp = buf;

	for (i = 64; i; i--, spr++) {
		if ((spr->tile != 0) && (spr->x == envyro->ply_x) && (spr->y == envyro->ply_y)) {
			selspr = spr;
		}
	}

	if (selspr != NULL) {
		for (i = (12*14); i; i--, bp++) {
			*bp = 0x100 + ' ';
		}

		if (selspr->flag & 0x0F) {
			p += offs[(selspr->flag & 0x0F) - 1];
		} else {
			if ((selspr->flag >> 4) != 0x0C) {
				p = default_transact_text;
			} else {
				p = default_enemy_transact_text;
			}
		}

		bp = buf;
		if (!(*p)) {
			*bp = 0x100;
		}
		while (*p) {
			if ((*p == 0x0A) || (*p == 0x0D)) {
				bp = buf + (((bp - buf) / 12) * 12) + 12; // Just some temporary code
			} else {
				*bp = 0x100 + (*p);
				bp++;
			}
			p++;
		}
		set_bkg_map(buf, 20, 10, 12, 14);
	}
}

void load_tileset() {
	int i;
	struct tile_def *tile = tileset_map;

	for (i = 0; i != (TILESET_SIZE*4); i += 4, tile++) {
		load_tiles(u3_tileset+(tile->tile_number << 7), i, 4, 4);
	}
}

void build_frame() {
	load_tiles(frame_tiles, 256, 31, 4);
	set_bkg_map(frame_map, 0, 0, 32, 24);
}

void main() {
	struct envyronment envyro;

	int ply_x = 0;
	int ply_y = 0;
	int joy;

	set_vdp_reg(VDP_REG_FLAGS1, VDP_REG_FLAGS1_SCREEN | VDP_REG_FLAGS1_8x16);
	load_palette(bkg_pal1, 0, 16);
	load_palette(spr_pal1, 16, 16);
	load_tiles(u3_font, 256, 192, 4);
	build_frame();
	load_tileset();

	envyro.map = sosaria_map;

	for (;;) {
		joy = read_joypad1();
		if (joy & JOY_UP) {
			ply_y--;
		}
		if (joy & JOY_DOWN) {
			ply_y++;
		}
		if (joy & JOY_LEFT) {
			ply_x--;
		}
		if (joy & JOY_RIGHT) {
			ply_x++;
		}
		if (joy & JOY_FIREA) {
			display_text(&envyro);
		}

		ply_x &= MAP_W_MASK;
		ply_y &= MAP_H_MASK;

		wait_vblank_noint();
		draw_map(&envyro, ply_x, ply_y);
		animate_tileset(&envyro);

		if (pause_flag) {
			envyro.map = british_map;
		} else {
			envyro.map = sosaria_map;
		}

		envyro.timer++;
	}
}

#asm
._frame_map
	BINARY	"frame.map"
._frame_tiles
	BINARY	"frame_tiles.bin"
._u3_font
	BINARY	"font.bin"
._u3_tileset
	BINARY	"tileset1.til"
	BINARY	"sprites1.til"
._british_map
	BINARY	"british.twn"
._sosaria_map
	BINARY	"sosaria.wld"
#endasm
