#include <stdlib.h>
#include <string.h>
#include <sms.h>

/**
 * TODO:
 *    - Victory pose (maybe putting on the head?)
 *    - Atari-like option selection
 *    - Let the player serve the ball
 *    - Double ninjas option
 *    - 1p vs CPU option
 *    - 1p+2p vs CPU option
 *    - CGA palette option (Play the game in Black, Cyan, Magenta and Gray, for an extra retro look)
 *    - Improve the sound
 *    - Cleaning up this ugly code
 */

#define OPTION_MSK_CPU 0x01
#define OPTION_MSK_PAL 0x06
#define OPTION_MSK_PAL_RGB 0x00
#define OPTION_MSK_PAL_CGA 0x02
#define OPTION_MSK_PAL_BW 0x04
#define OPTION_MSK_PAL_MONO 0x06

typedef struct _actor {
	int x, y;
	char w, h;
	fixed step_x, step_y;
	fixed spd_x, spd_y;
	int max_x;
	int tile_no;
	int frame_no;
	int tmr;
	char bounce;
	int last_bounce_x;
	char bounced;
	char on_ground;
	char middle_barrier;
	char fireb_delay;
	char snd_timer;
} actor;

extern unsigned char sortem_tileset_apk[];
extern unsigned char court_tileset_apk[];
extern unsigned char option_tileset_apk[];
extern unsigned int court_background_map[];

unsigned char pal_main_rgb[] = {0x00, 0x30, 0x03, 0x0C, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
unsigned char pal_red_rgb[] = {0x03, 0x30, 0x03, 0x0C, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
unsigned char pal_main_cga[] = {0x00, 0x28, 0x22, 0x2A, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
unsigned char pal_red_cga[] = {0x22, 0x28, 0x22, 0x2A, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
unsigned char pal_main_bw[] = {0x00, 0x15, 0x2A, 0x3F, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
unsigned char pal_red_bw[] = {0x3F, 0x15, 0x2A, 0x3F, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
unsigned char pal_main_mono[] = {0x00, 0x3F, 0x3F, 0x3F, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
unsigned char pal_red_mono[] = {0x3F, 0x00, 0x00, 0x00, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

void load_main_tileset() {
	unsigned char buffer[4096];

	aplib_depack(sortem_tileset_apk, buffer);
	load_tiles(buffer, 0, 96, 4);

	aplib_depack(option_tileset_apk, buffer);
	load_tiles(buffer, 128, 96, 4);

	aplib_depack(court_tileset_apk, buffer);
	load_tiles(buffer, 256, 96, 4);
}

void draw_main_background() {
	/*
	int i;

	for (i = 0; i != 6; i++) {
		set_bkg_map(sortem_background_bg2+128, 0, i << 1, 32, 2);
	}
	set_bkg_map(sortem_background_bg2+192, 0, 12, 32, 2);
	for (i = 7; i != 14; i++) {
		set_bkg_map(sortem_background_bg2, 0, i << 1, 32, 2);
	}
	*/

	set_bkg_map(court_background_map, 0, 0, 32, 24);
}

int asr(int n, int cnt) {
	if (n < 0) {
		return -((-n) >> cnt);
	} else {
		return n >> cnt;
	}
}

void draw_number(int x, int y, int n) {
	UWORD buffer[4];
	int d0 = (n % 10) << 1;
	int d1 = (n / 10) << 1;
	UWORD *p = buffer;

	*p = (256 + 48) + d1;
	p++;
	*p = (256 + 48) + d0;
	p++;
	*p = (256 + 49) + d1;
	p++;
	*p = (256 + 49) + d0;

	set_bkg_map(buffer, x, y, 2, 2);
}

void update_score(int sc1, int sc2) {
	draw_number(4, 0, sc1);
	draw_number(25, 0, sc2);
}

void stop_moving(fixed *spd, char bounce) {
	if (bounce) {
		spd->w = -(WORD)spd->w;
	} else {
		spd->w = 0;
	}
}

void move_actor(actor *act) {
	unsigned int tx, ty;
	unsigned int tilenum;

	(WORD)act->step_y.w += (WORD)act->spd_y.w;
	act->y += (BYTE)act->step_y.b.h;
	act->step_y.b.h = 0;

	if ((BYTE)act->spd_y.b.h < 7) {
		(WORD)act->spd_y.w += 0x50;
	}

	act->bounced = 0;
	act->on_ground = 0;
	if (act->y < 16) {
		act->y = 16;
		stop_moving(&(act->spd_y), act->bounce);
		act->bounced = 1;
	} else if (act->y >= (192-16-16)) {
		act->y = (192-16-16);
		stop_moving(&(act->spd_y), act->bounce);
		act->bounced = 1;
		act->on_ground = 1;
	}

	(WORD)act->step_x.w += (WORD)act->spd_x.w;
	act->x += (BYTE)act->step_x.b.h;
	act->step_x.b.h = 0;

	if (act->x < 0) {
		act->x = 0;
		stop_moving(&(act->spd_x), act->bounce);
		act->bounced = 1;
	} else if (act->x > (256-16)) {
		act->x = (256-16);
		stop_moving(&(act->spd_x), act->bounce);
		act->bounced = 1;
	} else if (act->middle_barrier || (act->y > (96-24+2))) { // Actor below the net, or actor not allowed to cross it.
		if (((WORD)act->spd_x.w > 0) && (act->x > (128-16)) && (act->x < (128-8))) {
			// Collision on center wall from the left
			act->x = (128-16);
			stop_moving(&(act->spd_x), act->bounce);
			act->bounced = 1;
		} else if (((WORD)act->spd_x.w < 0) && (act->x > (128-8)) && (act->x < 128)) {
			// Collision on center wall from the right
			act->x = 128;
			stop_moving(&(act->spd_x), act->bounce);
			act->bounced = 1;
		}
	}

	if ((WORD)act->spd_x.w < -0x700) {
		act->spd_x.w = -0x700;
	} else if ((WORD)act->spd_x.w > 0x700) {
		act->spd_x.w = 0x700;
	}

	if ((WORD)act->spd_y.w < -0x700) {
		act->spd_y.w = -0x700;
	} else if ((WORD)act->spd_y.w > 0x700) {
		act->spd_y.w = 0x700;
	}

	act->tmr++;
}

void move_actor_joy(actor *act, actor *ball, int joy) {
	int sound_chan = 0;
	int sound_freq = 0;

	if (act->x > 128) {
		sound_chan = 1;
	}

	if (!act->snd_timer) {
		set_sound_volume(sound_chan, 0);
	} else {
		act->snd_timer--;
	}

	if (joy & JOY_LEFT) {
		if ((WORD)act->spd_x.w > -0x400) {
			(WORD)act->spd_x.w -= 0x50;
		}
	} else if (joy & JOY_RIGHT) {
		if ((WORD)act->spd_x.w < 0x400) {
			(WORD)act->spd_x.w += 0x50;
		}
	} else {
		if ((BYTE)act->spd_x.b.h < 0) {
			(WORD)act->spd_x.w += 0x50;
		} else if ((BYTE)act->spd_x.b.h > 0) {
			(WORD)act->spd_x.w -= 0x50;
		} else {
			act->spd_x.w = 0;
		}
	}

	if (!act->on_ground && (act->spd_y.b.h != 0)) { // "auto aim" while in air
		if (((act->x < 128) && (ball->x < 128)) || ((act->x > 128) && (ball->x > 128))) { // If player and ball are on the same side
			if (act->x > ball->x) {
				(WORD)act->spd_x.w -= 0x20;
			} else {
				(WORD)act->spd_x.w += 0x20;
			}
		}
	}

	if (joy & (JOY_FIREA|JOY_FIREB)) {
		if (act->on_ground) {
			(WORD)act->spd_y.w = -0x700;
			sound_freq = 300;
		} else {
			if ((act->x <= 0) || ((act->x > (128-8)) && (act->x <= 128))) {
				(WORD)act->spd_y.w = -0x700;
				(WORD)act->spd_x.w = 0x700;
				sound_freq = 270;
			} else if ((act->x >= (256-16)) || ((act->x >= (128-16)) && (act->x < (128-8)))) {
				(WORD)act->spd_y.w = -0x700;
				(WORD)act->spd_x.w = -0x700;
				sound_freq = 270;
			}
		}
	}

	if (act->fireb_delay > 1) {
		act->fireb_delay--;
	}

	move_actor(act);

	act->frame_no = 0;
	if (act->spd_x.w != 0) {
		if (act->on_ground) {
			act->frame_no = 8 + ((act->tmr >> 1) & 0x04);
		} else {
			act->frame_no = 4;
		}
	}
	if ((WORD)act->spd_x.w < 0) {
		act->frame_no += 16;
	}

	if (sound_freq) {
		set_sound_freq(sound_chan, sound_freq);
		set_sound_volume(sound_chan, 15);
		act->snd_timer = 4;
	}
}

void collide_actor_ball(actor *act, actor *ball) {
	int x1 = act->x - 2;
	int y1 = act->y - 2;
	int x2 = x1 + (act->w << 3) + 4;
	int y2 = y1 + (act->h << 3) + 4;
	/*
	int x1 = act->x - 4;
	int y1 = act->y - 4;
	int x2 = x1 + (act->w << 3) + 8;
	int y2 = y1 + (act->h << 3) + 8;
	*/

	int bx1 = ball->x;
	int by1 = ball->y;
	int bx2 = bx1 + (ball->w << 3);
	int by2 = by1 + (ball->h << 3);

	if ((((bx1 >= x1) && (bx1 <= x2)) || ((bx2 >= x1) && (bx2 <= x2))) &&
		(((by1 >= y1) && (by1 <= y2)) || ((by2 >= y1) && (by2 <= y2)))) { // Collided with the ball
		if ((ball->y < act->y) && (ball->y > act->y - 16)) {
			ball->y -= 4; // This is intended to make the ball easier to handle
		}

		ball->spd_x.w += act->spd_x.w;
		if ((WORD)ball->spd_x.w < -0x700) {
			(WORD)ball->spd_x.w = -0x700;
		} else if ((WORD)ball->spd_x.w > 0x700) {
			(WORD)ball->spd_x.w = 0x700;
		}
		if (act->x < 128) {
			ball->spd_y.w += 0x180; // This is intended to make sending the ball to the other side a little easier
		} else {
			ball->spd_y.w -= 0x180;
		}

		if ((WORD)act->spd_y.w < 0) {
			ball->spd_y.w += act->spd_y.w;
		} else {  // This is intended to make raising the ball a little easier
			ball->spd_y.w += (act->spd_y.w >> 1);
		}
		ball->spd_y.w -= 0x180; // This is intended to make raising the ball a little easier

		if ((WORD)ball->spd_y.w < -0x700) {
			(WORD)ball->spd_y.w = -0x700;
		} else if ((WORD)ball->spd_y.w > 0x700) {
			(WORD)ball->spd_y.w = 0x700;
		}
	}
}

void draw_actor(actor *act, int *curr_spr) {
	int x, y, tile;
	int i, j, y2;

	if (*curr_spr > 63) {
		return;
	}

	if (!act->tile_no) {
		return;
	}

	x = act->x;
	y = act->y;
	tile = act->tile_no + act->frame_no;

	if ((x < -16) || (x > 255) ||
	    (y < -16) || (y > 192)) {
		return;
	}

	for (i = act->w; i; i--, x += 8) {
		for (j = act->h, y2 = y; j; j--, y2 += 16, tile += 2, (*curr_spr)++) {
			set_sprite(*curr_spr, x, y2, tile);
		}
	}
}

int actor_ai(actor *cpu, actor *ply, actor *ball) {
	int joy = 0;

	if (ball->x >= 128) { // Ball on the right side of the field?
		if (cpu->x < ball->x) {
			joy |= JOY_RIGHT;
		} else {
			joy |= JOY_LEFT;
		}

		if (cpu->y > ball->y) {
			if (!(rand() & 0x01)) { // Just to slow its reaction a little
				joy |= JOY_FIREA;
			}
		}
	} else { // Ball on the left side of the field?
		// Position itself at a strategical coordinate
		if (cpu->x < 192) {
			joy |= JOY_RIGHT;
		} else if (cpu->x > 192) {
			joy |= JOY_LEFT;
		}
	}

	return joy;
}

void draw_option(int x, int y, int tile) {
	UWORD buffer[4], *p, *pend;

	for (p = buffer, pend=buffer+4; p != pend; p++) {
		*p = tile;
		tile++;
	}

	set_bkg_map(buffer, x, y, 4, 1);
}

void draw_options(int options) {
	draw_option(14, 4, 128 + ((options & OPTION_MSK_CPU) << 2));
	draw_option(14, 6, 128 + ((options & OPTION_MSK_PAL) << 1) + 8);
}

void main() {
	int i;
	int joy, joy2;
	int curr_spr;
	actor actors[32];
	actor *act;
	int timer;
	int score1, score2;
	int explosion;
	int options = 0;

	unsigned char *pal_main = pal_main_rgb;
	unsigned char *pal_red = pal_red_rgb;

	for (;;) {
		load_palette(pal_main, 0, 16);
		load_palette(pal_main, 16, 16);
		load_main_tileset();
		draw_main_background()
		set_sprite(0, 208, 208, 0);
		set_vdp_reg(VDP_REG_FLAGS0, VDP_REG_FLAGS0_CHANGE);
		set_vdp_reg(VDP_REG_FLAGS1, VDP_REG_FLAGS1_SCREEN | VDP_REG_FLAGS1_8x16);

		joy = 0;
		draw_options(options);
		while (!(joy & (JOY_FIREA|JOY_FIREB))) {
			wait_vblank_noint();
			joy = read_joypad1();

			if (joy & (JOY_UP|JOY_DOWN|JOY_LEFT|JOY_RIGHT)) {
				if (joy & (JOY_DOWN|JOY_RIGHT)) {
					options++;
				} else {
					options--;
				}
				switch (options & OPTION_MSK_PAL) {
				case OPTION_MSK_PAL_RGB:
					pal_main = pal_main_rgb;
					pal_red = pal_red_rgb;
					break;
				case OPTION_MSK_PAL_CGA:
					pal_main = pal_main_cga;
					pal_red = pal_red_cga;
					break;
				case OPTION_MSK_PAL_BW:
					pal_main = pal_main_bw;
					pal_red = pal_red_bw;
					break;
				case OPTION_MSK_PAL_MONO:
					pal_main = pal_main_mono;
					pal_red = pal_red_mono;
					break;
				}
				load_palette(pal_main, 0, 16);
				load_palette(pal_main, 16, 16);
				draw_options(options);
			}
			while (joy & (JOY_UP|JOY_DOWN|JOY_LEFT|JOY_RIGHT)) {
				wait_vblank_noint();
				joy = read_joypad1();
			}
		}

		load_palette(pal_main, 0, 16);
		load_palette(pal_main, 16, 16);
		load_main_tileset();
		draw_main_background()
		set_sprite(0, 208, 208, 0);
		set_vdp_reg(VDP_REG_FLAGS0, VDP_REG_FLAGS0_CHANGE);
		set_vdp_reg(VDP_REG_FLAGS1, VDP_REG_FLAGS1_SCREEN | VDP_REG_FLAGS1_8x16);

		act = actors;
		act->x = 128;
		act->y = 16;
		act->w = 2;
		act->h = 1;
		act->step_x.w = 0;
		act->step_y.w = 0;
		act->spd_x.w = 0x150;
		if (rand() & 0x01) {
			(WORD)act->spd_x.w = -(WORD)act->spd_x.w;
		}
		act->spd_y.w = 0x0;
		act->tile_no = 16;
		act->frame_no = 0;
		act->bounce = 1;
		act->last_bounce_x = 128;
		act->on_ground = 0;
		act->middle_barrier = 0;

		act++;
		act->x = 16;
		act->y = 96;
		act->w = 2;
		act->h = 1;
		act->step_x.w = 0;
		act->step_y.w = 0;
		act->spd_x.w = 0;
		act->spd_y.w = 0;
		act->tile_no = 32;
		act->frame_no = 0;
		act->bounce = 0;
		act->on_ground = 0;
		act->middle_barrier = 1;
		act->fireb_delay = 0;
		act->snd_timer = 0;

		act++;
		act->x = 240;
		act->y = 96;
		act->w = 2;
		act->h = 1;
		act->step_x.w = 0;
		act->step_y.w = 0;
		act->spd_x.w = 0;
		act->spd_y.w = 0;
		act->tile_no = 32;
		act->frame_no = 0;
		act->bounce = 0;
		act->on_ground = 0;
		act->middle_barrier = 1;
		act->fireb_delay = 0;
		act->snd_timer = 0;

		score1 = 0;
		score2 = 0;
		update_score(score1, score2);

		explosion = 0;

		while ((score1 < 15) && (score2 < 15)) {
			joy = read_joypad1();
			if (options & OPTION_MSK_CPU) {
				joy2 = actor_ai(actors+2, actors+1, actors);
			} else {
				joy2 = read_joypad2();
			}

			/*
			for (i = 0, act = actors; i != 3; i++, act++) {
				move_actor(act);
			}
			*/
			if (!explosion) {
				if (timer & 0x01) {
					act = actors;
					move_actor(act);
					act->frame_no = (act->tmr & 0x0C);
					if ((act->last_bounce_x < 128) && (act->x < 128) && (act->last_bounce_x > 128) && (act->x > 128)) {
						act->last_bounce_x = 128;
					}
					if (act->on_ground) {
						set_sound_freq(2, 250);
						set_sound_volume(2, 15);

						if (act->x < 128) {
							if (act->last_bounce_x < 128) {
								explosion = 70;
							}
						} else {
							if (act->last_bounce_x > 128) {
								explosion = 70;
							}
						}
						act->last_bounce_x = act->x;
					} else {
						if (((act->x < 128) && (act->last_bounce_x > 128)) ||
							((act->x > 128) && (act->last_bounce_x < 128))) {
							act->last_bounce_x = 128;
						}
						if (act->bounced) {
							set_sound_freq(2, 200);
							set_sound_volume(2, 15);
						} else {
							set_sound_volume(2, 0);
						}
					}
				}
				move_actor_joy(actors+1, actors, joy);
				move_actor_joy(actors+2, actors, joy2);

				collide_actor_ball(actors+1, actors);
				collide_actor_ball(actors+2, actors);
			} else {
				explosion--;
				if (!explosion) {
					set_sound_volume(3, 0);

					act = actors;
					if (act->x < 128) {
						score2++;
						act->spd_x.w = 0x150;
					} else {
						score1++;
						(WORD)act->spd_x.w = -0x150;
					}
					act->x = 128;
					act->y = 16;
					act->step_x.w = 0;
					act->step_y.w = 0;
					act->spd_y.w = 0;
					act->last_bounce_x = 128;
					update_score(score1, score2);
					load_palette(pal_main, 0, 16);
				} else {
					act = actors;
					if (act->x < 128) {
						act = actors+1;
					} else {
						act = actors+2;
					}
					if (act->frame_no < 32) {
						act->frame_no = 32;
					} else {
						if ((explosion & 0x03) == 0x02) {
							act->frame_no += 4;
						}
					}

					if (explosion & 0x02) {
						load_palette(pal_main, 0, 16);
						set_sound_freq(2, 300);
						set_sound_volume(2, 15);
						set_sound_freq(3, 4);
						set_sound_volume(3, 15);
					} else {
						load_palette(pal_red, 0, 16);
						set_sound_freq(2, 350);
						set_sound_volume(2, 15);
						set_sound_freq(3, 6);
						set_sound_volume(3, 15);
					}
				}
			}

			wait_vblank_noint();

			curr_spr = 0;
			for (i = 0, act = actors; i != 3; i++, act++) {
				draw_actor(act, &curr_spr);
			}
			if (curr_spr < 64) {
				set_sprite(curr_spr, 208, 208, 0);
			}

			timer++;
		}
	}

}

#asm
._sortem_tileset_apk
	BINARY	"sortem.apk"
._court_tileset_apk
	BINARY	"court.apk"
._option_tileset_apk
	BINARY	"option.apk"
._court_background_map
	BINARY	"court.map"
#endasm
