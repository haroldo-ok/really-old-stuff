#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sms.h>

#define TERRAIN_COLUMNS 32
#define TERRAIN_ROWS 20
#define TERRAIN_MIN_HEIGHT 4
#define TERRAIN_HEIGHT_VARIANCE (TERRAIN_ROWS-TERRAIN_MIN_HEIGHT)
#define TERRAIN_TOP 4
#define TERRAIN_IRREGULARITY 128
#define TERRAIN_FP_ROWS (TERRAIN_ROWS << 4)
#define TERRAIN_FP_MIN_HEIGHT (TERRAIN_MIN_HEIGHT << 4)
#define TERRAIN_FP_HEIGHT_VARIANCE (TERRAIN_HEIGHT_VARIANCE << 4)
#define TERRAIN_FP_TOP (TERRAIN_TOP << 4)

#define MAX_TANKS 2
#define MAX_SHOTS 8

#define SHOT_SPR 0x1B
#define BLAST_SPR 0x1C
#define TANK_SPR 0x20

#define GRAVITY_ACCEL 0x02

typedef struct _actor {
	int x;
	int y;
	int spd_x;
	int spd_y;
	int base_tile;
	char w;
	char h;
	int frame_no;
	char hit_ground;
	char place_on_ground;
} actor;

typedef struct _tank {
	actor act;
	int angle;
	int power;
	int life;
	int score;
} tank;

typedef struct _envyronment {
	tank tanks[MAX_TANKS];
	actor shots[MAX_SHOTS];
	int terrain[TERRAIN_COLUMNS];
	char next_sprite;
	tank *curr_tank;
	char player_done;
	char update_status;
	char round_done;
	unsigned int clock;
} envyronment;

unsigned char pal1[] = {0x00, 0x20, 0x08, 0x28, 0x02, 0x22, 0x0A, 0x2A,
				0x15, 0x35, 0x1E, 0x3E, 0x17, 0x37, 0x0F, 0x3F};

/*unsigned char pal_white[] = {0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F,
				0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F};

unsigned char pal_black[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
				0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};*/

unsigned char sin_table[] = {
	0, 4, 8, 13, 17, 22, 26, 31, 35, 40,
	44, 48, 53, 57, 61, 66, 70, 74, 79, 83,
	87, 91, 95, 100, 104, 108, 112, 116, 120, 124,
	127, 131, 135, 139, 143, 146, 150, 154, 157, 161,
	164, 167, 171, 174, 177, 181, 184, 187, 190, 193,
	196, 198, 201, 204, 207, 209, 212, 214, 217, 219,
	221, 223, 226, 228, 230, 232, 233, 235, 237, 238,
	240, 242, 243, 244, 246, 247, 248, 249, 250, 251,
	252, 252, 253, 254, 254, 255, 255, 255, 255, 255,
};

extern unsigned char terrain_tileset_apk[];
extern unsigned char map1_apk[];
extern unsigned char font8_apk[];
extern unsigned char pal_terrain[];

void calc_sin(int angle) {
	int ang2 = angle % 180;
	int res = 0;

	angle %= 360;

	if (ang2 >= 90) {
		res = sin_table[180-ang2];
	} else {
		res = sin_table[ang2];
	}

	if (angle > 180) {
		return -res;
	} else {
		return res;
	}
}

void calc_cos(int angle) {
	return calc_sin(angle+90);
}

void load_main_font() {
	unsigned char buffer[2048];
	aplib_depack(font8_apk, buffer);
	load_tiles(buffer, 0, 256, 1);
}

void load_main_tileset() {
	unsigned char buffer[4096];
	aplib_depack(terrain_tileset_apk, buffer);
	load_tiles(buffer, 256, 128, 4);
}

int rand_height() {
	return (rand() % TERRAIN_FP_HEIGHT_VARIANCE) + TERRAIN_FP_MIN_HEIGHT;
}

int rand_height_delta() {
	return (rand() % TERRAIN_IRREGULARITY) - (TERRAIN_IRREGULARITY >> 1);
}

void generate_terrain_slice(int *lo, int *hi, int size) {
	int *mid = lo + (size >> 1);
	int h = ((*lo)+(*hi)) >> 1;

	if (size < 2) {
		return;
	}

	h += rand_height_delta();
	if (h < TERRAIN_FP_MIN_HEIGHT) {
		h = TERRAIN_FP_MIN_HEIGHT;
	}
	if (h >= TERRAIN_FP_ROWS) {
		h = TERRAIN_FP_ROWS - 1;
	}
	*mid = h;

	generate_terrain_slice(lo, mid, size >> 1);
	generate_terrain_slice(mid, hi, size >> 1);
}

void soften_terrain(int *terrain) {
	unsigned char i;
	int *p = terrain;
	int *p2 = terrain+1;

	for (i = 0; i != (TERRAIN_COLUMNS-1); i++, p++, p2++) {
		*p = ((*p)+(*p2)) >> 1;
	}
}

void generate_terrain(envyronment *envyro) {
	int *lo = envyro->terrain;
	int *hi = envyro->terrain + (TERRAIN_COLUMNS-1);

	*lo = rand_height();
	*hi = rand_height();

	generate_terrain_slice(lo, hi, TERRAIN_COLUMNS);
	soften_terrain(envyro->terrain);
	soften_terrain(envyro->terrain);
}

unsigned int peak_char(int l, int m, int r) {
	int n = 0;

	l >>= 4;
	m >>= 4;
	r >>= 4;

	if (l < m) {
		if ((m - l) > 1) {
			n += 2;
		} else {
			n += 1;
		}
	}
	if (r < m) {
		if ((m - r) > 1) {
			n += 6;
		} else {
			n += 3;
		}
	}

	return 0x0111 + n;
}

void draw_terrain(envyronment *envyro) {
	unsigned char i, j;
	unsigned int column[TERRAIN_ROWS];
	unsigned int *p;
	int *h, th;
	unsigned int *prev_h = envyro->terrain;
	unsigned int *next_h = envyro->terrain+1;

	for (i = 0, h = envyro->terrain; i != TERRAIN_COLUMNS; i++, h++, next_h++) {
		for (j = 0, p = column; j != TERRAIN_ROWS; j++, p++) {
			*p = 0;
		}

		th = (*h) >> 4;
		p = column+TERRAIN_ROWS-th;
		if (i == (TERRAIN_COLUMNS-1)) {
			next_h--; // So that it doesn't "leak" in the last column
		}
		*p = peak_char(*prev_h, *h, *next_h);
		p++;

		for (j = th-1; j; j--, p++) {
			*p = 0x0110;
		}

		set_bkg_map(column, i, TERRAIN_TOP, 1, TERRAIN_ROWS);

		prev_h = h;
	}
}

void draw_actor(envyronment *envyro, actor *a) {
	char i, j;
	int x, y, til;

	if (!a->base_tile) {
		return;
	}

	if ((a->x < -4) || (a->x > (256 << 4)) ||
	    (a->y < -4) || (a->y > (192 << 4))) {
		return;
	}

	til = a->base_tile + a->frame_no;
	x = (a->x >> 4) - 4;
	for (i = a->w; i; i--, x += 8) {
		y = (a->y >> 4) - 4;
		for (j = a->h; j; j--, y += 8, til++) {
			set_sprite(envyro->next_sprite, x, y, til);
			envyro->next_sprite++;
		}
	}
}

void move_actor(envyronment *envyro, actor *a) {
	int x = a->x >> 7;
	int y = TERRAIN_FP_TOP + TERRAIN_FP_ROWS;

	if (!(a->base_tile)) {
		return;
	}

	if ((x >= 0) && (x < TERRAIN_COLUMNS)) {
		y = TERRAIN_FP_TOP + TERRAIN_FP_ROWS - envyro->terrain[x];
	}

	a->x += a->spd_x;
	a->y += a->spd_y;
	a->spd_y += GRAVITY_ACCEL;

	if (a->y > (y << 3)) {
		if (a->place_on_ground) {
			a->y = y << 3;
		}
		a->spd_y = 0;
		a->hit_ground = 1;
	}
}

void blast_terrain(envyronment *envyro, int x, int str) {
	int y;

	x >>= 7;

	if ((x >= 0) && (x < TERRAIN_COLUMNS)) {
		y = envyro->terrain[x];
		if (y > TERRAIN_FP_MIN_HEIGHT) {
			envyro->terrain[x] -= str;
		}
	}
}

void check_hit_tanks(envyronment *envyro, actor *a) {
	tank *tnk;
	char i;
	int dx, dy;

	for (i = 0, tnk = envyro->tanks; i != MAX_TANKS; i++, tnk++) {
		dx = a->x - tnk->act.x;
		dy = a->y - tnk->act.y;

		if (abs(dy) < (4 << 4)) {
			if ((dx > -(4 << 4)) && (dx < (12 << 4))) {
				tnk->life--;
			}
		}
	}
}

void move_shot(envyronment *envyro, actor *a) {
	if (a->base_tile == BLAST_SPR) {
		if (!(envyro->clock & 0x01)) {
			a->frame_no++;
			if (a->frame_no == 4) {
				a->base_tile = 0;
			}
		}
		return;
	}

	move_actor(envyro, a);

	if ((a->x < -4) || (a->x > (TERRAIN_COLUMNS << 7))) {
		a->base_tile = 0;
	}

	if (a->hit_ground) {
		blast_terrain(envyro, a->x-(3 << 4), 0x08);
		blast_terrain(envyro, a->x, 0x08);
		blast_terrain(envyro, a->x+(3 << 4), 0x08);

		check_hit_tanks(envyro, a);

		draw_terrain(envyro);

		a->hit_ground = 0;
		a->base_tile = BLAST_SPR;
	}
}

char no_shots(envyronment *envyro) {
	return !(envyro->shots->base_tile);
}

void place_at_ground(actor *a, int *terrain) {
	int x = a->x >> 7;
	int y = TERRAIN_FP_TOP + TERRAIN_FP_ROWS - terrain[x];

	a->y = y << 3;
}

void draw_number(int n, int x, int y, int w) {
	char buf[6];
	char *p;
	unsigned int val;

	memset(buf, ' ', 6);
	buf[w] = 0;

	p = buf + w - 1;
	*p = '0';

	for (val =  abs(n); val; val /= 10, p--) {
		*p = '0' + val % 10;
	}

	if (n < 0) {
		*p = '-';
	}

	gotoxy(x, y);
	puts(buf);
}

void draw_tank_status(tank *tnk) {
	gotoxy(0,1);
	puts("Ang");
	draw_number(tnk->angle, 4, 1, 3);
	gotoxy(0,2);
	puts("Pwr");
	draw_number(tnk->power, 4, 2, 3);
}

void update_status_bar(envyronment *envyro) {
	draw_tank_status(envyro->curr_tank);
	gotoxy(12,1);
	puts("1P");
	draw_number(envyro->tanks->score, 16, 1, 4);
	gotoxy(12,2);
	puts("2P");
	draw_number((envyro->tanks+1)->score, 16, 2, 4);
	gotoxy(22,1);
	if (envyro->curr_tank != envyro->tanks) {
		puts("2P");
	} else {
		puts("1P");
	}

	envyro->update_status = 0;
}

void fire_cannon(envyronment *envyro, tank *tnk) {
	envyro->shots->x = tnk->act.x;
	envyro->shots->y = tnk->act.y;
	envyro->shots->spd_x = tnk->power*calc_cos(tnk->angle)/256;
	envyro->shots->spd_y = -tnk->power*calc_sin(tnk->angle)/256;
	envyro->shots->w = 1;
	envyro->shots->h = 1;
	envyro->shots->base_tile = SHOT_SPR;
	envyro->shots->frame_no = 0;
	envyro->shots->hit_ground = 0;
	envyro->shots->place_on_ground = 0;
	envyro->player_done = 1;
}

void control_tank(envyronment *envyro, int joy, tank *tnk) {
	if (joy & JOY_UP) {
		tnk->power++;
		envyro->update_status = 1;
	}
	if (joy & JOY_DOWN) {
		tnk->power--;
		envyro->update_status = 1;
	}
	if (joy & JOY_LEFT) {
		tnk->angle++;
		envyro->update_status = 1;
	}
	if (joy & JOY_RIGHT) {
		tnk->angle--;
		envyro->update_status = 1;
	}
	if (joy & JOY_FIREA) {
		fire_cannon(envyro, tnk);
	}
}

void place_tank(envyronment *envyro, tank *tnk, int x, int angle) {
	tnk->act.x = x << 4;
	tnk->act.y = 0;
	tnk->act.spd_x = 0;
	tnk->act.spd_y = 0;
	tnk->act.w = 2;
	tnk->act.h = 1;
	tnk->act.base_tile = TANK_SPR;
	tnk->act.frame_no = 0;
	tnk->act.place_on_ground = 1;
	tnk->angle = angle;
	tnk->power = 50;
	tnk->life = 1;
	place_at_ground(tnk, envyro->terrain);
}

void main() {
	int i;
	int joy;
	envyronment envyro;
	tank *tnk;

	load_palette(pal_terrain, 0, 16);
	load_palette(pal_terrain, 16, 16);
	load_main_font();
	load_main_tileset();
	set_vdp_reg(VDP_REG_FLAGS1, VDP_REG_FLAGS1_SCREEN);
//	set_vdp_reg(VDP_REG_FLAGS1, VDP_REG_FLAGS1_SCREEN);
	set_vdp_reg(0x86, 0x04); // Use the 2nd charset for the sprites

	gotoxy(1, 22);
//	puts("Artillery Master v0.01");
	puts("Press any button");
	while (!(read_joypad1() & (JOY_FIREA | JOY_FIREB))) {
		rand();
		wait_vblank_noint();
	}

	for (;;) {
		generate_terrain(&envyro);
		draw_terrain(&envyro);

		tnk = envyro.tanks;
		place_tank(&envyro, tnk, 32, 60);

		tnk++;
		place_tank(&envyro, tnk, 224, 150);

		envyro.curr_tank = envyro.tanks;

		envyro.player_done = 0;

		update_status_bar(&envyro);

		for (envyro.round_done = 0; !envyro.round_done;) {
			joy = read_joypad1();

			if (!envyro.player_done) {
				control_tank(&envyro, joy, envyro.curr_tank);
			}

			tnk = envyro.tanks;
			move_actor(&envyro, &(tnk->act));
			tnk++;
			move_actor(&envyro, &(tnk->act));
			move_shot(&envyro, envyro.shots);

			if (envyro.player_done && no_shots(&envyro)) {
				// Hit any of the tanks?
				if ((envyro.tanks->life <= 0) || ((envyro.tanks+1)->life <= 0)) {
					if (envyro->curr_tank->life <= 0) {
						// Hit itself?
						envyro->curr_tank->score--;
					} else {
						envyro->curr_tank->score++;
					}
					envyro.round_done = 1;
				}

				envyro.curr_tank++;
				if (envyro.curr_tank >= (envyro.tanks + MAX_TANKS)) {
					envyro.curr_tank = envyro.tanks;
				}
				envyro.player_done = 0;
				envyro.update_status = 1;
			}

			envyro.clock++;

			wait_vblank_noint();

			envyro.next_sprite = 0;

			tnk = envyro.tanks;
			draw_actor(&envyro, &(tnk->act));
			tnk++;
			draw_actor(&envyro, &(tnk->act));
			draw_actor(&envyro, envyro.shots);

			for (i = envyro.next_sprite; i != 16; i++) {
				set_sprite(i, -8, -8, 0);
			}

			if (envyro.update_status) {
				update_status_bar(envyro);
			}
		}
	}
}

#asm
._terrain_tileset_apk
	BINARY	"terrain.apk"
._map1_apk
	BINARY	"map1.apk"
._font8_apk
	BINARY	"font8.apk"
._pal_terrain
	BINARY	"terrain.pal"
#endasm
